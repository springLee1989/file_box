#!/bin/bash
ipset create setmefree hash:net
#ipset -N setmefree iphash -!
ipset create ipcheck hash:net
#ipset -N ipcheck iphash -!
ipset create tencent hash:net
#ipset -N tencent iphash -!
#weixin ips

ipset add tencent 113.96.0.0/12
ipset add tencent 14.208.0.0/12
ipset add tencent 203.205.192.0/18
ipset add ipcheck 59.36.112.0/20
ipset add ipcheck 183.0.0.0/10
ipset add ipcheck 121.8.0.0/13
#ipset -N ss_bypass_set iphash -!
# ipset create ss_bypass_set hash:net
# ipset add ss_bypass_set 8.134.0.0/16
# ipset add ss_bypass_set 120.79.0.0/16
# ipset add ss_bypass_set 120.74.0.0/16
# ipset add ss_bypass_set 119.23.55.156
# ipset add ss_bypass_set 47.104.0.0/13
# ipset add ss_bypass_set 120.76.0.0/14
# ipset add ss_bypass_set 101.132.142.183
dnsFile="/etc/dnsmasq.d/fgset.conf"
chnroute_file="/tmp/cn_ip_range.txt"
if [ -f $chnroute_file ]; then       
     echo "CN route_file  exist"
else                                 
    wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/gohome/cn_ip_range.txt.tar.gz -O /tmp/cn_ip_range.txt.tar.gz
    tar xzf /tmp/cn_ip_range.txt.tar.gz -C /tmp/
fi 

if [ -f $chnroute_cn_file ]; then
     echo "CN route_file  exist"
fi

rm -rf /etc/dnsmasq.d/*.conf

wget --no-check-certificate  https://gitee.com/spring1989/file_box/raw/master/gohome/cdns.tar.gz -O /tmp/dns.tar.gz
tar xzf /tmp/dns.tar.gz -C /etc/dnsmasq.d/



cpu=`awk 'NR==1,NR==1 {print $5}' /proc/cpuinfo`
obfs="/usr/bin/obfs-local"
md5sum /etc/init.d/ss-yunlink > /tmp/md5sum.txt
etc_init_md5=`awk 'NR==1,NR==1 {print $1}' /tmp/md5sum.txt`
machine=`awk 'NR==2,NR==2 {print $3}' /proc/cpuinfo`

#ipset create ss_bypass_set hash:net

# ss_redir_pid=/var/run/shadowsocks.pid
# ss_config_file=/etc/config/shadowsocks.json

sed -i "s/iptables/# xxxxx/g" /etc/firewall.user
sed -i "s/ipset/# xxxxx/g" /etc/firewall.user
# 开启redir
#ss-redir -u -c $ss_config_file -f $ss_redir_pid

# 添加ss地址到ipset
# ipset add ss_bypass_set $ss_server_ip

# 添加chinaroute到ipset
if [ -f $chnroute_file ]; then       
    IPS=`which ipset`                
    for i in `cat $chnroute_file `;  
    do                               
      ipset add setmefree $i     
    done                             
    echo "China route was loaded"    
else                                 
    echo "China route does not exist"
fi 

ssport=1080
obfsport=1058
ss_redir_port=8082
obfs_s_port=2082
maclist=($(cat /sys/class/net/eth[1-5]/address|awk -F ":" '{print $1""$2""$3""$4""$5""$6 }'| tr a-z A-Zs))
iptables -t nat -N TENCENT_SS
# TCP规制微信
for((i=0;i<${#maclist[@]};i++)) 
    do
        iptables -t nat -A TENCENT_SS -p tcp -i eth$(($i + 1))  -m set --match-set ipcheck dst -j REDIRECT --to-port $(($ssport + $i))
        iptables -t nat -A TENCENT_SS -p tcp -i eth$(($i + 1))  -m set --match-set tencent dst -j REDIRECT --to-port $(($ssport + $i))
    done
iptables -t nat -A OUTPUT -p tcp -j TENCENT_SS
iptables -t nat -A PREROUTING -p tcp -j TENCENT_SS

# iptables -t nat -N SHADOWSOCKS_TCP
# iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set ss_bypass_set dst -j RETURN
# iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 80 -j RETURN
# iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 443 -j RETURN
# iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 12356 -j RETURN
# #iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 444:7999 -j RETURN
# #iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 8010:65534 -j RETURN
# ## iptables -t nat -A SHADOWSOCKS_TCP -p tcp -m set --match-set setmefree dst -j REDIRECT --to-ports 1080

# # TCP规制
# for((i=0;i<${#maclist[@]};i++)) 
#     do
#         iptables -t nat -A SHADOWSOCKS_TCP -p tcp -i eth$(($i + 1))  -m set --match-set setmefree dst -j REDIRECT --to-port $(($ssport + $i))
#     done


# # Apply for tcp
# iptables -t nat -A OUTPUT -p tcp -j SHADOWSOCKS_TCP
# iptables -t nat -A PREROUTING -p tcp -j SHADOWSOCKS_TCP
# # UDP规则
iptables -t mangle -N SHADOWSOCKS_UDP
iptables -t mangle -N SHADOWSOCKS_UDP_MARK

ip route add local default dev lo table 100
ip rule add fwmark 1 lookup 100
#iptables -t mangle -A SHADOWSOCKS_UDP -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1900 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 8100:65534 -j RETURN

# iptables -t mangle -A SHADOWSOCKS_UDP -p udp -j TPROXY --on-port $ss_redir_port --tproxy-mark 0x01/0x01
for((i=0;i<${#maclist[@]};i++)) 
   do
       iptables -t mangle -A SHADOWSOCKS_UDP -i eth$(($i + 1)) -p udp -m set --match-set setmefree dst -j TPROXY --on-port $(($ssport + $i + 10)) --tproxy-mark 0x01/0x01
       iptables -t mangle -A SHADOWSOCKS_UDP -i eth$(($i + 1)) -p udp -m set --match-set tencent dst -j TPROXY --on-port $(($ssport + $i + 10)) --tproxy-mark 0x01/0x01
       iptables -t mangle -A SHADOWSOCKS_UDP -i eth$(($i + 1)) -p udp -m set --match-set ipcheck dst -j TPROXY --on-port $(($ssport + $i + 10)) --tproxy-mark 0x01/0x01
   done

#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1900 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 8100:65534 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -j MARK --set-mark 1
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set setmefree dst -j MARK --set-mark 1
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set tencent dst -j MARK --set-mark 1
#Apply for udp
iptables -t mangle -A PREROUTING -p udp -j SHADOWSOCKS_UDP
iptables -t mangle -A OUTPUT -p udp -j SHADOWSOCKS_UDP_MARK


#tdx ips
ipset add tencnet 120.79.60.82
ipset add tencnet 8.129.13.54
ipset add tencnet 120.24.149.49
ipset add tencent 47.113.94.204
ipset add tencent 8.129.174.169
ipset add tencent 47.113.123.248
ipset add tencent 47.103.48.45
ipset add tencent 47.100.236.28
ipset add tencent 101.133.214.242
ipset add tencent 47.116.21.80
ipset add tencent 47.116.105.28
ipset add tencent 47.116.10.29
ipset add tencent 39.98.234.173
ipset add tencent 39.98.198.249
ipset add tencent 39.100.68.59
ipset add tencent 106.53.96.220
ipset add tencent 106.53.99.72
ipset add tencent 106.55.12.89
ipset add tencent 49.235.34.65
ipset add tencent 106.54.160.69
ipset add tencent 1.116.4.119
ipset add tencent 121.5.179.92
ipset add tencent 121.5.42.84
ipset add tencent 121.5.49.235
ipset add tencent 159.75.207.200
ipset add tencent 159.75.228.136
ipset add tencent 222.73.228.220
ipset add tencent 210.51.54.194
ipset add tencent 192.168.0.188
ipset add tencent 112.74.214.43
ipset add tencent 120.25.218.6
ipset add tencent 47.107.75.159
ipset add tencent 47.106.204.218
ipset add tencent 47.106.209.131
ipset add tencent 119.97.185.5
ipset add tencent 59.175.238.38
ipset add tencent 106.14.95.149
ipset add tencent 47.102.108.214
ipset add tencent 192.168.0.179

#cft ip range


ipset add tencent 180.163.69.187
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 120.77.124.184
ipset add tencent 101.37.131.0
ipset add tencent 42.159.201.206
ipset add tencent 42.159.107.85
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 121.52.237.66
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 115.159.252.71
ipset add tencent 120.77.126.79
ipset add tencent 120.55.16.52
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 121.52.237.66
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 139.219.105.105
ipset add tencent 139.219.105.105
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 120.77.124.184
ipset add tencent 101.37.131.0
ipset add tencent 61.129.249.104
ipset add tencent 61.129.249.103
ipset add tencent 42.159.201.206
ipset add tencent 42.159.107.85
ipset add tencent 42.159.252.10
ipset add tencent 119.23.113.82
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 61.129.248.107
ipset add tencent 183.136.164.249
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 61.129.248.231
ipset add tencent 120.77.126.79
ipset add tencent 120.55.16.52
ipset add tencent 42.159.252.10
ipset add tencent 119.23.113.82
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 61.129.248.107
ipset add tencent 183.136.164.249
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 61.129.129.226
ipset add tencent 61.129.129.226
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 120.77.124.184
ipset add tencent 101.37.131.0
ipset add tencent 42.159.201.206
ipset add tencent 42.159.107.85
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 120.199.7.78
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 115.159.252.71
ipset add tencent 120.77.126.79
ipset add tencent 120.55.16.52
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 120.199.7.78
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 120.77.124.184
ipset add tencent 101.37.131.0
ipset add tencent 61.129.249.104
ipset add tencent 61.129.249.103
ipset add tencent 42.159.201.206
ipset add tencent 42.159.107.85
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 120.199.7.78
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 115.159.252.71
ipset add tencent 120.77.126.79
ipset add tencent 120.55.16.52
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 42.159.142.107
ipset add tencent 40.125.207.153
ipset add tencent 120.199.7.78
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 120.77.124.184
ipset add tencent 101.37.131.0
ipset add tencent 61.129.249.104
ipset add tencent 61.129.249.103
ipset add tencent 42.159.201.206
ipset add tencent 42.159.107.85
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 61.129.248.107
ipset add tencent 42.159.142.107
ipset add tencent 119.23.113.82
ipset add tencent 40.125.207.153
ipset add tencent 183.136.164.249
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 61.129.248.105
ipset add tencent 116.62.90.9
ipset add tencent 119.23.113.18
ipset add tencent 139.219.225.32
ipset add tencent 40.125.205.35
ipset add tencent 115.159.252.71
ipset add tencent 120.77.126.79
ipset add tencent 120.55.16.52
ipset add tencent 42.159.252.10
ipset add tencent 139.219.105.5
ipset add tencent 116.62.95.111
ipset add tencent 61.129.248.107
ipset add tencent 42.159.142.107
ipset add tencent 119.23.113.82
ipset add tencent 40.125.207.153
ipset add tencent 183.136.164.249
ipset add tencent 180.163.69.219
ipset add tencent 101.37.96.7
ipset add tencent 139.217.3.165
ipset add tencent 115.159.252.74
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 139.219.105.105
ipset add tencent 61.129.129.226
ipset add tencent 222.46.18.212
ipset add tencent 222.46.18.212
ipset add tencent 210.32.125.153
ipset add tencent 210.32.125.153
ipset add tencent 202.104.236.88
ipset add tencent 202.104.236.72
ipset add tencent 202.104.236.72
ipset add tencent 202.104.236.88
ipset add tencent 202.104.236.7
ipset add tencent 202.104.236.68
ipset add tencent 202.104.236.72
ipset add tencent 202.104.236.15
ipset add tencent 123.129.204.152
ipset add tencent 120.199.7.78
ipset add tencent 180.163.69.219
for((i=0;i<${#maclist[@]};i++)) 
    do
        mac=${maclist[i]}
        /usr/bin/ssr-redir -c /etc/shadowsocks/$mac.json  -b 0.0.0.0 -l $(($ssport + $i)) -s 127.0.0.1 -p $(($obfsport + $i)) 2>/dev/null &
        /usr/bin/ssr-redir -c /etc/shadowsocks/$mac-u.json  -b 0.0.0.0 -l $(($ssport + $i + 10)) -u 2>/dev/null &
    done
for((i=0;i<${#maclist[@]};i++))
    do
        mac=${maclist[i]}
        /usr/bin/obfs-local  -c /etc/shadowsocks/$mac.json  -p 2082 -l $(($obfsport + $i)) --obfs http 2>/dev/null &
    done
echo "ss-redir is loaded" 