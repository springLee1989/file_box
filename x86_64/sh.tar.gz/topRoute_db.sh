#!/bin/bash
ipset create setmefree hash:net
ipset -N setmefree iphash -!
ipset create tencent hash:net
ipset -N tencent iphash -!
ipset add tencent 183.0.0.0/10
ipset add tencent 113.96.0.0/12
ipset add tencent 14.208.0.0/12
ipset add tencent 203.205.192.0/18
ipset -N ss_bypass_set iphash -!
ipset add ss_bypass_set 8.134.0.0/16
ipset add ss_bypass_set 120.79.0.0/16
ipset add ss_bypass_set 120.74.0.0/16
ipset add ss_bypass_set 119.23.55.156
ipset add ss_bypass_set 47.104.0.0/13
ipset add ss_bypass_set 120.76.0.0/14
dnsFile="/etc/dnsmasq.d/fgset.conf"
chnroute_file="/tmp/cn_ip_range.txt"
if [ -f $chnroute_file ]; then       
     echo "CN route_file  exist"
else                                 
    wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/gohome/cn_ip_range.txt.tar.gz -O /tmp/cn_ip_range.txt.tar.gz
    tar xzf /tmp/cn_ip_range.txt.tar.gz -C /tmp/
fi 

if [ -f $chnroute_cn_file ]; then
     echo "CN route_file  exist"
fi

rm -rf /etc/dnsmasq.d/*.conf

wget --no-check-certificate  https://gitee.com/spring1989/file_box/raw/master/gohome/cdns.tar.gz -O /tmp/dns.tar.gz
tar xzf /tmp/dns.tar.gz -C /etc/dnsmasq.d/



cpu=`awk 'NR==1,NR==1 {print $5}' /proc/cpuinfo`
obfs="/usr/bin/obfs-local"
md5sum /etc/init.d/ss-yunlink > /tmp/md5sum.txt
etc_init_md5=`awk 'NR==1,NR==1 {print $1}' /tmp/md5sum.txt`
machine=`awk 'NR==2,NR==2 {print $3}' /proc/cpuinfo`

#ipset create ss_bypass_set hash:net

# ss_redir_pid=/var/run/shadowsocks.pid
# ss_config_file=/etc/config/shadowsocks.json

sed -i "s/iptables/# xxxxx/g" /etc/firewall.user
sed -i "s/ipset/# xxxxx/g" /etc/firewall.user
# 开启redir
#ss-redir -u -c $ss_config_file -f $ss_redir_pid

# 添加ss地址到ipset
# ipset add ss_bypass_set $ss_server_ip

# 添加chinaroute到ipset
if [ -f $chnroute_file ]; then       
    IPS=`which ipset`                
    for i in `cat $chnroute_file `;  
    do                               
      ipset add setmefree $i     
    done                             
    echo "China route was loaded"    
else                                 
    echo "China route does not exist"
fi 

ssport=1080
obfsport=1058
ss_redir_port=8082
obfs_s_port=2082
maclist=($(cat /sys/class/net/eth[1-5]/address|awk -F ":" '{print $1""$2""$3""$4""$5""$6 }'| tr a-z A-Zs))
iptables -t nat -N TENCENT_SS
# TCP规制
for((i=0;i<${#maclist[@]};i++)) 
    do
        iptables -t nat -A TENCENT_SS -p tcp -i eth$(($i + 1))  -m set --match-set tencent dst -j REDIRECT --to-port $(($ssport + $i))
    done

iptables -t nat -A OUTPUT -p tcp -j TENCENT_SS
iptables -t nat -A PREROUTING -p tcp -j TENCENT_SS



iptables -t nat -N SHADOWSOCKS_TCP
iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set ss_bypass_set dst -j RETURN
iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 80 -j RETURN
iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 443 -j RETURN
iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 12356 -j RETURN
## iptables -t nat -A SHADOWSOCKS_TCP -p tcp -m set --match-set setmefree dst -j REDIRECT --to-ports 1080

# TCP规制
for((i=0;i<${#maclist[@]};i++)) 
    do
        iptables -t nat -A SHADOWSOCKS_TCP -p tcp -i eth$(($i + 1))  -m set --match-set setmefree dst -j REDIRECT --to-port $(($ssport + $i))
    done


# Apply for tcp
iptables -t nat -A OUTPUT -p tcp -j SHADOWSOCKS_TCP
iptables -t nat -A PREROUTING -p tcp -j SHADOWSOCKS_TCP
# UDP规则
iptables -t mangle -N SHADOWSOCKS_UDP
iptables -t mangle -N SHADOWSOCKS_UDP_MARK

ip route add local default dev lo table 100
ip rule add fwmark 1 lookup 100
#iptables -t mangle -A SHADOWSOCKS_UDP -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1900 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 8100:65534 -j RETURN

# iptables -t mangle -A SHADOWSOCKS_UDP -p udp -j TPROXY --on-port $ss_redir_port --tproxy-mark 0x01/0x01
for((i=0;i<${#maclist[@]};i++)) 
   do
       iptables -t mangle -A SHADOWSOCKS_UDP -i eth$(($i + 1)) -p udp -m set --match-set setmefree dst -j TPROXY --on-port $(($ssport + $i + 10)) --tproxy-mark 0x01/0x01
   done

#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1900 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 8100:65534 -j RETURN
#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -j MARK --set-mark 1
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set setmefree dst -j MARK --set-mark 1

#Apply for udp
iptables -t mangle -A PREROUTING -p udp -j SHADOWSOCKS_UDP
iptables -t mangle -A OUTPUT -p udp -j SHADOWSOCKS_UDP_MARK



for((i=0;i<${#maclist[@]};i++)) 
    do
        mac=${maclist[i]}
        /usr/bin/ssr-redir -c /etc/shadowsocks/$mac.json  -b 0.0.0.0 -l $(($ssport + $i)) -s 127.0.0.1 -p $(($obfsport + $i)) 2>/dev/null &
        /usr/bin/ssr-redir -c /etc/shadowsocks/$mac-u.json  -b 0.0.0.0 -l $(($ssport + $i+10)) -u 2>/dev/null &
    done
    for((i=0;i<${#maclist[@]};i++))
    do
        mac=${maclist[i]}
        /usr/bin/obfs-local  -c /etc/shadowsocks/$mac.json  -p $(($obfs_s_port + $i)) -l $(($obfsport + $i)) --obfs http 2>/dev/null &
    done

echo "ss-redir is loaded"
