#!/bin/sh
##添加chinaroute到ipset
ipset create setmefree hash:net

wget --no-check-certificate  https://gitee.com/spring1989/file_box/raw/master/dns.tar.gz -O /tmp/dns.tar.gz
tar xzf /tmp/dns.tar.gz -C /tmp/dnsmasq.d/

# TCP规则
iptables -t nat -N CN_TCP

iptables -t nat -A CN_TCP -p tcp -m set --match-set setmefree dst -j REDIRECT --to-ports 1080
/etc/init.d/dnsmasq restart
echo "yunlink_service is loaded"

