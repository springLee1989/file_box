#!/bin/sh
##添加chinaroute到ipset
ipset create setmefree hash:net
ipset create tencent hash:net
ipset -N tencent iphash -!
ipset add tencent 183.0.0.0/10
dnsFile="/etc/dnsmasq.d/fgset.conf"
chnroute_file="/tmp/cn_ip_range.txt"
if [ -f $chnroute_file ]; then       
     echo "CN route_file  exist"
else                                 
    wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/gohome/cn_ip_range.txt.tar.gz -O /tmp/cn_ip_range.txt.tar.gz
    tar xzf /tmp/cn_ip_range.txt.tar.gz -C /tmp/
fi 

if [ -f $chnroute_cn_file ]; then
     echo "CN route_file  exist"
fi
if [ -f $dnsFile ];then
    rm -rf /etc/dnsmasq.d/*.conf
fi
rm -rf /etc/dnsmasq.d/*.conf
if [ "`uci get system.@system[0].hostname`" == "Yunlink3" ];then
rm -rf /etc/dnsmasq.d/gfwlist.conf
wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/zgq.conf.tar.gz -O /root/zgq.conf.tar.gz
tar xzf /root/zgq.conf.tar.gz -C /etc/dnsmasq.d/
else
	if [ "`uci get system.@system[0].hostname`" == "YunLink1s-gohome" ];then
		rm -rf /etc/dnsmasq.d/*.conf
        wget --no-check-certificate  https://gitee.com/spring1989/file_box/raw/master/gohome/cdns.tar.gz -O /tmp/dns.tar.gz
		tar xzf /tmp/dns.tar.gz -C /etc/dnsmasq.d/
	else
		wget --no-check-certificate  https://gitee.com/spring1989/file_box/raw/master/dns.tar.gz -O /tmp/dns.tar.gz
		tar xzf /tmp/dns.tar.gz -C /etc/dnsmasq.d/
	fi
fi


cpu=`awk 'NR==1,NR==1 {print $5}' /proc/cpuinfo`
obfs="/usr/bin/obfs-local"
md5sum /etc/init.d/ss-yunlink > /tmp/md5sum.txt
etc_init_md5=`awk 'NR==1,NR==1 {print $1}' /tmp/md5sum.txt`
machine=`awk 'NR==2,NR==2 {print $3}' /proc/cpuinfo`

if [ ! -e $obfs -a $cpu == "MT7620N" ];then
	wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/2026/simple-obfs_v0.0.5-spring-3_ramips_24kec.ipk -O /tmp/simple-obfs_v0.0.5-spring-3_ramips_24kec.ipk
	wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/2026/libev_4.19-1_ramips_24kec.ipk -O /tmp/libev_4.19-1_ramips_24kec.ipk
	opkg install /tmp/libev_4.19-1_ramips_24kec.ipk
	opkg install /tmp/simple-obfs_v0.0.5-spring-3_ramips_24kec.ipk
fi
if [ $cpu == "MT7620N" -a $etc_init_md5 != "8b4d32f37da11cef5ad53d340d33f5b5" -a "`uci get system.@system[0].hostname`" == "YunLink1s-gohome" ];then
	wget --no-check-certificate   https://gitee.com/spring1989/file_box/raw/master/gohome/ss-yunlink -O /etc/init.d/ss-yunlink 
	chmod a+x  /etc/init.d/ss-yunlink
	/etc/init.d/ss-yunlink restart
fi


if [ -f $chnroute_file ]; then       
    IPS=`which ipset`                
    for i in `cat $chnroute_file `;  
    do                               
      ipset add setmefree $i     
    done
    echo "CN route was loaded"    
else                                 
    echo "CN route does not exist"
fi 
iptables -t nat -N TENCENT_SS
# TCP规制
iptables -t nat -A TENCENT_SS -p tcp -m set --match-set tencent dst -j REDIRECT --to-ports 1080

iptables -t nat -A OUTPUT -p tcp -j TENCENT_SS
iptables -t nat -A PREROUTING -p tcp -j TENCENT_SS
# TCP规则
iptables -t nat -N SHADOWSOCKS_TCP

#iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 80 -j RETURN
#iptables -t nat -A SHADOWSOCKS_TCP -p tcp  -m set --match-set setmefree dst --dport 443 -j RETURN
iptables -t nat -A SHADOWSOCKS_TCP -p tcp -m set --match-set setmefree dst -j REDIRECT --to-ports 1080

# Apply for tcp
iptables -t nat -A OUTPUT -p tcp -j SHADOWSOCKS_TCP
iptables -t nat -A PREROUTING -p tcp -j SHADOWSOCKS_TCP
#ipset -N setmefree iphash -!
#iptables -t nat -A PREROUTING -p tcp -m set --match-set setmefree dst -j REDIRECT --to-port 1080

# UDP规则
iptables -t mangle -N SHADOWSOCKS_UDP
iptables -t mangle -N SHADOWSOCKS_UDP_MARK

ip route add local default dev lo table 100
ip rule add fwmark 1 lookup 100
#iptables -t mangle -A SHADOWSOCKS_UDP -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp --dport 1900 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP -p udp -m set --match-set setmefree dst -j TPROXY --on-port 8010 --tproxy-mark 0x01/0x01

#iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set ss_bypass_set dst -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 11:79 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1053 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp --dport 1900 -j RETURN
iptables -t mangle -A SHADOWSOCKS_UDP_MARK -p udp -m set --match-set setmefree dst -j MARK --set-mark 1

# Apply for udp
iptables -t mangle -A PREROUTING -p udp -j SHADOWSOCKS_UDP
iptables -t mangle -A OUTPUT -p udp -j SHADOWSOCKS_UDP_MARK

sed -i "s/iptables/# xxxxx/g" /etc/firewall.user
sed -i "s/ipset/# xxxxx/g" /etc/firewall.user
/etc/init.d/shadowsocksr stop
/etc/init.d/shadowsocksr disable
/etc/init.d/dnsmasq restart  2>/dev/null  &
echo "ss-redir is loaded"

